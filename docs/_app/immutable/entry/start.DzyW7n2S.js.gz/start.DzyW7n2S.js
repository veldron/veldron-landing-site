import{l as o,a as r}from"../chunks/Bkr0ggpY.js";export{o as load_css,r as start};
