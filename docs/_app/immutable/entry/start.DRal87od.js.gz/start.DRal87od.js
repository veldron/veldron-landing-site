import{l as o,a as r}from"../chunks/DOaUOAZz.js";export{o as load_css,r as start};
